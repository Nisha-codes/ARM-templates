const express = require('express');
const { BlobServiceClient } = require('@azure/storage-blob');
const sql = require('mssql');
const app = express();

app.get('/', async (req, res) => {
  try {
    // Storage: list containers
    const storageConn = process.env.STORAGE_CONN_STRING;
    const blobSvc = BlobServiceClient.fromConnectionString(storageConn);
    const containers = [];
    for await (const c of blobSvc.listContainers()) containers.push(c.name);

    // SQL: create table if missing, insert a row, read latest
    const sqlConn = process.env.SQL_CONN_STRING;
    await sql.connect(sqlConn);
    const q = `
      IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Messages]') AND type in (N'U'))
      BEGIN
        CREATE TABLE Messages (Id INT IDENTITY(1,1) PRIMARY KEY, Text NVARCHAR(100));
      END
      INSERT INTO Messages (Text) VALUES ('Hello from the app');
      SELECT TOP 1 Text FROM Messages ORDER BY Id DESC;
    `;
    const r = await sql.query(q);
    const latest = r.recordset && r.recordset.length ? r.recordset[0].Text : '(none)';

    res.send('Containers: ' + containers.join(', ') + '  |  Latest message: ' + latest);
  } catch (err) {
    console.error(err);
    res.status(500).send('Error: ' + err.message);
  } finally {
    try { await sql.close(); } catch(e) {}
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log('App listening on', port));
